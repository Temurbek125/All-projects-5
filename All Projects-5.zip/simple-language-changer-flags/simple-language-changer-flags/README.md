# Simple language changer flags

A Pen created on CodePen.io. Original URL: [https://codepen.io/Azametzin/pen/rZJYpa](https://codepen.io/Azametzin/pen/rZJYpa).

